//
//  main.cpp
//  Compress
//
//  Created by DB on 4/29/17.
//  Copyright © 2017 D Blalock. All rights reserved.
//

//#include <iostream>

#define CATCH_CONFIG_RUNNER
#include "catch.hpp"

int main(int argc, char *const argv[]) {
    return Catch::Session().run(argc, argv);
}
