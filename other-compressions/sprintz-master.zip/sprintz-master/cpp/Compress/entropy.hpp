//
//  entropy.hpp
//  Compress
//
//  Created by DB on 10/24/17.
//  Copyright © 2017 D Blalock. All rights reserved.
//

#ifndef entropy_hpp
#define entropy_hpp

#include <stdio.h>

#endif /* entropy_hpp */
