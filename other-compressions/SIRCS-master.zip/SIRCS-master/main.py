from tkinter import *
from GUI import *
root = Tk()
fr = Framework(root)
fr.initial_frame()
root.mainloop()
