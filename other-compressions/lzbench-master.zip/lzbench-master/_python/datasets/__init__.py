#!/usr/bin/env python

# from .datasets import *  # noqa

# from pamap import getAllPamapRecordings
# from pamap2 import getAllPamap2Recordings
# from ucr import allUCRDatasets, smallUCRDatasets, origUCRDatasets
